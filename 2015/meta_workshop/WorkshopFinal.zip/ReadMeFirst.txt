FILES FOR META-ANALYSIS WORKSHOP AT TRI-SOCIETIES (NOVEMEBER 2015) 
BY LARRY MADDEN (OHIO STATE UNIVERSTIY)

Meta-analysis Tri Societies 2015 MADDEN (1 slide per page color).pdf
	Pdf of the power point. Best used by viewing on monitor
	during the workshop. NOT for printing.
Meta-analysis Tri Societies 2015 MADDEN (6 slides per page grey scale).pdf
	Pdf of the power point, with six slides per page.
	Can be used for printing before the workshop (or later).
meta-macros.sas				
	SAS file containing a collection of macros. 
	Run this once at the start of the SAS session.
meta-analysis Shah slope example.sas	
	This is case study #2 (first one analyzed in SAS)
	We will go through this slowly, part by part.
meta_quilt.sas
	This is case study #3
	We will go through this slowly, part by part.
Test of data input for SAS University Edition.sas
	Tester program for University Edition (UE) users only.
	Run this in UE before the workshop.
	Will not run in regular SAS.
shah_meta_slope.txt
	Text file of raw data for case study #2 (not needed)
quilt.txt
	Text file of raw data for case study #3 (not needed)


BACKGROUND MATERIAL:
Madden&Paul_meta-analysis_overview_Jan2011.pdf
	Previously published article that covers concepts of meta-analysis.
Madden&Paul_meta-analysis_eXtra_overview_Jan2011.pdf
	On-line supplement for above article.
Meta references MADDEN 2015.pdf
	A somewhat arbitrary list of important books and articles.
	Many are referenced in the workshop. 
	




